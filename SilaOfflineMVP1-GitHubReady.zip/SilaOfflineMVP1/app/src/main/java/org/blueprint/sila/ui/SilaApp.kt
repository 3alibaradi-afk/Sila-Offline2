package org.blueprint.sila.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import org.blueprint.sila.data.ChatMessage
import org.blueprint.sila.data.Peer
import org.blueprint.sila.data.PeerStatus
import org.blueprint.sila.nearby.TransportState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SilaNavy = Color(0xFF10263D)
private val SilaBlue = Color(0xFF1B6CA8)
private val SilaTeal = Color(0xFF0D8B78)
private val SilaGreen = Color(0xFF15805B)
private val SilaAmber = Color(0xFFB96A16)
private val SilaRed = Color(0xFFB33B3B)
private val SilaSurface = Color(0xFFF5F7FA)
private val SilaBorder = Color(0xFFDCE3EA)

private val SilaColors = lightColorScheme(
    primary = SilaBlue,
    onPrimary = Color.White,
    secondary = SilaTeal,
    background = SilaSurface,
    surface = Color.White,
    surfaceVariant = Color(0xFFEDF2F6),
    onSurface = SilaNavy,
    onSurfaceVariant = Color(0xFF52616E),
    error = SilaRed
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SilaApp(
    viewModel: MainViewModel,
    onRequestPermissions: () -> Unit,
    onOpenBluetoothSettings: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var draft by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(state.messages.size, state.peers.size) {
        if (state.messages.isNotEmpty()) {
            val peerItems = maxOf(1, state.peers.size)
            val lastMessageIndex = 4 + peerItems + state.messages.lastIndex
            listState.animateScrollToItem(lastMessageIndex)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = SilaColors) {
            Surface(modifier = Modifier.fillMaxSize(), color = SilaSurface) {
                Scaffold(
                    containerColor = SilaSurface,
                    topBar = {
                        TopAppBar(
                            colors = TopAppBarDefaults.topAppBarColors(containerColor = SilaNavy),
                            title = {
                                Column {
                                    Text("صلة", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                    Text("شبكة محلية مستقلة", color = Color(0xFFC7D7E7), fontSize = 12.sp)
                                }
                            },
                            actions = {
                                Text(
                                    "دون إنترنت",
                                    color = Color.White,
                                    modifier = Modifier
                                        .padding(end = 12.dp)
                                        .border(1.dp, Color(0xFF7892AA), RoundedCornerShape(20.dp))
                                        .padding(horizontal = 10.dp, vertical = 5.dp),
                                    fontSize = 12.sp
                                )
                            }
                        )
                    }
                ) { innerPadding ->
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(innerPadding),
                        state = listState,
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            NetworkHero(
                                state = state,
                                onStart = viewModel::startNetwork,
                                onStop = viewModel::stopNetwork,
                                onPermissions = onRequestPermissions,
                                onBluetooth = onOpenBluetoothSettings
                            )
                        }

                        item {
                            SectionTitle("الأجهزة القريبة", if (state.isDiscovering) "يتم البحث الآن" else null)
                        }

                        if (state.peers.isEmpty()) {
                            item {
                                EmptyCard(
                                    title = if (state.isDiscovering) "نبحث عن أجهزة صلة…" else "لم يبدأ البحث بعد",
                                    subtitle = if (state.isDiscovering)
                                        "ضع الهاتفين قريبين، وشغّل Bluetooth وWi‑Fi عليهما."
                                    else "اضغط «بدء الشبكة المحلية» على الهاتفين."
                                )
                            }
                        } else {
                            items(state.peers, key = { it.endpointId }) { peer ->
                                PeerCard(peer = peer, onConnect = { viewModel.connect(peer.endpointId) })
                            }
                        }

                        item { HorizontalDivider(color = SilaBorder) }
                        item { SectionTitle("الرسائل المحلية", if (state.connectedEndpointId != null) "اتصال مباشر" else "بانتظار اتصال") }

                        if (state.messages.isEmpty()) {
                            item {
                                EmptyCard(
                                    title = "لا توجد رسائل بعد",
                                    subtitle = "بعد الاتصال بجهاز قريب ستظهر الرسائل هنا، وتبقى محفوظة محليًا."
                                )
                            }
                        } else {
                            items(state.messages, key = { it.id }) { MessageBubble(it) }
                        }

                        item {
                            MessageComposer(
                                draft = draft,
                                onDraftChange = { draft = it },
                                enabled = state.connectedEndpointId != null,
                                onSend = {
                                    viewModel.sendMessage(draft)
                                    draft = ""
                                }
                            )
                        }

                        item {
                            Text(
                                "صلة 0.2 • الاتصال في هذه النسخة يتم عبر Nearby Connections. لا تُرسل الرسائل إلى خادم إنترنت.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            state.pendingConnection?.let { request ->
                AlertDialog(
                    onDismissRequest = {},
                    title = { Text("تأكيد جهاز قريب", fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("الجهاز: ${request.peerName}")
                            Text("قارن الرمز على الهاتفين. اقبل فقط إذا كان متطابقًا.")
                            Surface(
                                color = Color(0xFFEAF2FA),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    request.authenticationDigits,
                                    modifier = Modifier.padding(18.dp),
                                    textAlign = TextAlign.Center,
                                    style = MaterialTheme.typography.headlineLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = SilaNavy
                                )
                            }
                        }
                    },
                    confirmButton = { Button(onClick = viewModel::acceptConnection) { Text("الرمز مطابق") } },
                    dismissButton = { TextButton(onClick = viewModel::rejectConnection) { Text("رفض") } }
                )
            }

            state.error?.let { error ->
                AlertDialog(
                    onDismissRequest = viewModel::clearError,
                    title = { Text("تعذر تشغيل الاتصال", fontWeight = FontWeight.Bold) },
                    text = { Text(error) },
                    confirmButton = { TextButton(onClick = viewModel::clearError) { Text("حسنًا") } }
                )
            }
        }
    }
}

@Composable
private fun NetworkHero(
    state: TransportState,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onPermissions: () -> Unit,
    onBluetooth: () -> Unit
) {
    val connected = state.connectedEndpointId != null
    val active = state.isAdvertising || state.isDiscovering || connected
    val statusColor = when {
        connected -> SilaGreen
        active -> SilaBlue
        state.readyForNetwork -> SilaTeal
        else -> SilaAmber
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(48.dp).clip(CircleShape).background(statusColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(statusColor))
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        when {
                            connected -> "متصل بجهاز قريب"
                            state.isStarting -> "جارٍ تشغيل الشبكة…"
                            active -> "الشبكة المحلية تعمل"
                            state.readyForNetwork -> "جاهز للاتصال"
                            else -> "يلزم إكمال التهيئة"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = SilaNavy
                    )
                    Text(state.lastEvent, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                HealthPill("الأذونات", state.permissionsGranted, Modifier.weight(1f))
                HealthPill("Bluetooth", state.bluetoothEnabled, Modifier.weight(1f))
                HealthPill("خدمات Google", state.playServicesAvailable, Modifier.weight(1f))
            }

            if (state.airplaneMode) {
                Surface(color = Color(0xFFFFF4E5), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "وضع الطيران مفعّل. هذا مناسب لاختبار الانقطاع، لكن أعد تشغيل Bluetooth وWi‑Fi يدويًا.",
                        modifier = Modifier.padding(12.dp),
                        color = Color(0xFF7A4A0A),
                        fontSize = 13.sp
                    )
                }
            }

            if (!state.permissionsGranted) {
                Button(onClick = onPermissions, modifier = Modifier.fillMaxWidth()) { Text("منح أذونات الأجهزة القريبة") }
            }
            if (!state.bluetoothEnabled) {
                OutlinedButton(onClick = onBluetooth, modifier = Modifier.fillMaxWidth()) { Text("فتح إعدادات Bluetooth") }
            }

            if (active || state.networkRequested) {
                OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth()) { Text("إيقاف الشبكة المحلية") }
            } else {
                Button(
                    onClick = onStart,
                    enabled = !state.isStarting,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SilaBlue)
                ) { Text("بدء الشبكة المحلية", fontWeight = FontWeight.Bold) }
            }

            Text(
                "${state.localName}  •  ${state.nodeId.take(8).uppercase()}",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelMedium
            )
        }
    }
}

@Composable
private fun HealthPill(label: String, ok: Boolean, modifier: Modifier = Modifier) {
    val color = if (ok) SilaGreen else SilaAmber
    Row(
        modifier = modifier.clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.09f)).padding(9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 11.sp, color = color, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SectionTitle(title: String, note: String?) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = SilaNavy)
        if (note != null) Text(note, style = MaterialTheme.typography.labelMedium, color = SilaBlue)
    }
}

@Composable
private fun EmptyCard(title: String, subtitle: String) {
    Surface(
        modifier = Modifier.fillMaxWidth().border(1.dp, SilaBorder, RoundedCornerShape(18.dp)),
        color = Color.White,
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = SilaNavy)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
    }
}

@Composable
private fun PeerCard(peer: Peer, onConnect: () -> Unit) {
    val statusText = when (peer.status) {
        PeerStatus.DISCOVERED -> "متاح للاتصال"
        PeerStatus.CONNECTING -> "جارٍ الاتصال…"
        PeerStatus.CONNECTED -> "متصل"
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFE8F1F8)), contentAlignment = Alignment.Center) {
                Text(peer.name.takeLast(2), fontWeight = FontWeight.Bold, color = SilaBlue)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(peer.name, fontWeight = FontWeight.Bold, color = SilaNavy)
                Text(statusText, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
            Button(onClick = onConnect, enabled = peer.status == PeerStatus.DISCOVERED) {
                Text(if (peer.status == PeerStatus.CONNECTED) "متصل" else "اتصال")
            }
        }
    }
}

@Composable
private fun MessageComposer(draft: String, onDraftChange: (String) -> Unit, enabled: Boolean, onSend: () -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = draft,
                onValueChange = onDraftChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(if (enabled) "اكتب رسالة…" else "اتصل بجهاز أولًا") },
                enabled = enabled,
                maxLines = 4,
                shape = RoundedCornerShape(16.dp)
            )
            Button(onClick = onSend, modifier = Modifier.fillMaxWidth(), enabled = enabled && draft.isNotBlank()) {
                Text("إرسال محلي")
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val alignment = if (message.outgoing) Alignment.End else Alignment.Start
    val bubbleColor = if (message.outgoing) Color(0xFFDCEEFE) else Color.White
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        Column(
            modifier = Modifier.fillMaxWidth(0.86f).clip(RoundedCornerShape(18.dp)).background(bubbleColor).padding(12.dp)
        ) {
            Text(message.senderName, fontWeight = FontWeight.Bold, color = SilaNavy, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text(message.text, color = SilaNavy)
            Spacer(Modifier.height(5.dp))
            Text(
                SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp)),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
