package org.blueprint.sila.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import org.blueprint.sila.data.ChatMessage
import org.blueprint.sila.data.Peer
import org.blueprint.sila.data.PeerStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SilaApp(
    viewModel: MainViewModel,
    onRequestPermissions: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var draft by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) listState.animateScrollToItem(state.messages.lastIndex)
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Scaffold(
                topBar = { TopAppBar(title = { Text("صلة — اتصال محلي دون إنترنت") }) }
            ) { innerPadding ->
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    state = listState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        StatusCard(
                            localName = state.localName,
                            shortNodeId = state.nodeId.take(8),
                            advertising = state.isAdvertising,
                            discovering = state.isDiscovering,
                            connected = state.connectedEndpointId != null,
                            onStart = viewModel::startNetwork,
                            onStop = viewModel::stopNetwork,
                            onPermissions = onRequestPermissions
                        )
                    }

                    item {
                        Text("الأجهزة القريبة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    if (state.peers.isEmpty()) {
                        item { Text("لا توجد أجهزة مكتشفة بعد. شغّل الشبكة على هاتفين قريبين.") }
                    } else {
                        items(state.peers, key = { it.endpointId }) { peer ->
                            PeerRow(peer = peer, onConnect = { viewModel.connect(peer.endpointId) })
                        }
                    }

                    item { HorizontalDivider() }
                    item {
                        Text("الرسائل", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    if (state.messages.isEmpty()) {
                        item { Text("بعد الاتصال، أرسل رسالة لاختبار النقل المحلي.") }
                    } else {
                        items(state.messages, key = { it.id }) { message -> MessageBubble(message) }
                    }

                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = draft,
                                onValueChange = { draft = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("رسالة") },
                                enabled = state.connectedEndpointId != null,
                                minLines = 2
                            )
                            Button(
                                onClick = {
                                    viewModel.sendMessage(draft)
                                    draft = ""
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = state.connectedEndpointId != null && draft.isNotBlank()
                            ) {
                                Text("إرسال محلي")
                            }
                        }
                    }
                }
            }
        }

        state.pendingConnection?.let { request ->
            AlertDialog(
                onDismissRequest = {},
                title = { Text("تحقق من الاتصال") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("الجهاز: ${request.peerName}")
                        Text("تأكد أن الرمز نفسه ظاهر على الهاتف الآخر:")
                        Text(
                            request.authenticationDigits,
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = viewModel::acceptConnection) { Text("الرمز مطابق — قبول") }
                },
                dismissButton = {
                    TextButton(onClick = viewModel::rejectConnection) { Text("رفض") }
                }
            )
        }

        state.error?.let { error ->
            AlertDialog(
                onDismissRequest = viewModel::clearError,
                title = { Text("تعذر تنفيذ العملية") },
                text = { Text(error) },
                confirmButton = {
                    TextButton(onClick = viewModel::clearError) { Text("حسنًا") }
                }
            )
        }
    }
}

@Composable
private fun StatusCard(
    localName: String,
    shortNodeId: String,
    advertising: Boolean,
    discovering: Boolean,
    connected: Boolean,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onPermissions: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(localName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Node ID: $shortNodeId…")
            Text(if (connected) "الحالة: متصل بجهاز قريب" else "الحالة: غير متصل")
            Text("الإعلان: ${if (advertising) "يعمل" else "متوقف"} • البحث: ${if (discovering) "يعمل" else "متوقف"}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onStart) { Text("تشغيل الشبكة") }
                OutlinedButton(onClick = onStop) { Text("إيقاف") }
            }
            TextButton(onClick = onPermissions) { Text("طلب أذونات الأجهزة القريبة") }
        }
    }
}

@Composable
private fun PeerRow(peer: Peer, onConnect: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(peer.name, fontWeight = FontWeight.Bold)
                Text(
                    when (peer.status) {
                        PeerStatus.DISCOVERED -> "تم اكتشافه"
                        PeerStatus.CONNECTING -> "جارٍ الاتصال"
                        PeerStatus.CONNECTED -> "متصل"
                    }
                )
            }
            Button(
                onClick = onConnect,
                enabled = peer.status == PeerStatus.DISCOVERED
            ) {
                Text(if (peer.status == PeerStatus.CONNECTED) "متصل" else "اتصال")
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val alignment = if (message.outgoing) Alignment.End else Alignment.Start
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.86f)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                .padding(10.dp)
        ) {
            Text(message.senderName, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(message.text)
            Spacer(Modifier.height(4.dp))
            Text(
                SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp)),
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}
