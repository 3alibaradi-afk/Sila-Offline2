package org.blueprint.sila.data

import android.content.Context
import java.util.UUID

class LocalIdentity(context: Context) {
    private val prefs = context.getSharedPreferences("sila_identity", Context.MODE_PRIVATE)

    val nodeId: String = prefs.getString(KEY_NODE_ID, null) ?: UUID.randomUUID().toString().also {
        prefs.edit().putString(KEY_NODE_ID, it).apply()
    }

    val displayName: String = prefs.getString(KEY_DISPLAY_NAME, null) ?: run {
        val generated = "عقدة-${nodeId.take(4).uppercase()}"
        prefs.edit().putString(KEY_DISPLAY_NAME, generated).apply()
        generated
    }

    companion object {
        private const val KEY_NODE_ID = "node_id"
        private const val KEY_DISPLAY_NAME = "display_name"
    }
}
