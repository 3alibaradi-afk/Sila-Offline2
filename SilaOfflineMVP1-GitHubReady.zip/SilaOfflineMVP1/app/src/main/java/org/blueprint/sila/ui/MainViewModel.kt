package org.blueprint.sila.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import org.blueprint.sila.nearby.NearbyTransport

class MainViewModel(context: Context) : ViewModel() {
    private val transport = NearbyTransport(context)
    val state = transport.state

    fun startNetwork() = transport.startNetwork()
    fun stopNetwork() = transport.stopNetwork()
    fun connect(endpointId: String) = transport.connect(endpointId)
    fun acceptConnection() = transport.acceptPendingConnection()
    fun rejectConnection() = transport.rejectPendingConnection()
    fun sendMessage(text: String) = transport.sendMessage(text)
    fun clearError() = transport.clearError()

    override fun onCleared() {
        transport.shutdown()
        super.onCleared()
    }

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(context.applicationContext) as T
        }
    }
}
