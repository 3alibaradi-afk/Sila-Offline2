package org.blueprint.sila.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class MessageStore(context: Context) {
    private val prefs = context.getSharedPreferences("sila_messages", Context.MODE_PRIVATE)

    fun load(): List<ChatMessage> = runCatching {
        val raw = prefs.getString(KEY_MESSAGES, "[]") ?: "[]"
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    ChatMessage(
                        id = item.getString("id"),
                        senderName = item.getString("senderName"),
                        text = item.getString("text"),
                        timestamp = item.getLong("timestamp"),
                        outgoing = item.getBoolean("outgoing")
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    fun save(messages: List<ChatMessage>) {
        val array = JSONArray()
        messages.takeLast(200).forEach { message ->
            array.put(
                JSONObject()
                    .put("id", message.id)
                    .put("senderName", message.senderName)
                    .put("text", message.text)
                    .put("timestamp", message.timestamp)
                    .put("outgoing", message.outgoing)
            )
        }
        prefs.edit().putString(KEY_MESSAGES, array.toString()).apply()
    }

    companion object {
        private const val KEY_MESSAGES = "messages"
    }
}
