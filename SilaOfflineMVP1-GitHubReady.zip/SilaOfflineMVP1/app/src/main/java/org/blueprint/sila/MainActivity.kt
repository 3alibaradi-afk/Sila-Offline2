package org.blueprint.sila

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import org.blueprint.sila.ui.MainViewModel
import org.blueprint.sila.ui.SilaApp

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels { MainViewModel.Factory(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { /* UI lets the user retry if permissions were denied. */ }

            LaunchedEffect(Unit) {
                val permissions = requiredNearbyPermissions()
                if (permissions.isNotEmpty()) permissionLauncher.launch(permissions.toTypedArray())
            }

            SilaApp(
                viewModel = viewModel,
                onRequestPermissions = {
                    val permissions = requiredNearbyPermissions()
                    if (permissions.isNotEmpty()) permissionLauncher.launch(permissions.toTypedArray())
                }
            )
        }
    }

    private fun requiredNearbyPermissions(): List<String> = buildList {
        when {
            Build.VERSION.SDK_INT <= 28 -> add(Manifest.permission.ACCESS_COARSE_LOCATION)
            Build.VERSION.SDK_INT in 29..31 -> add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (Build.VERSION.SDK_INT >= 31) {
            add(Manifest.permission.BLUETOOTH_SCAN)
            add(Manifest.permission.BLUETOOTH_ADVERTISE)
            add(Manifest.permission.BLUETOOTH_CONNECT)
        }

        if (Build.VERSION.SDK_INT >= 33) {
            add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }

        if (Build.VERSION.SDK_INT >= 37) {
            add("android.permission.ACCESS_LOCAL_NETWORK")
        }
    }
}
