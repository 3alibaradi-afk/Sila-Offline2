package org.blueprint.sila

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import org.blueprint.sila.ui.MainViewModel
import org.blueprint.sila.ui.SilaApp

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels { MainViewModel.Factory(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) {
                viewModel.refreshSystemState(hasRequiredNearbyPermissions())
            }

            SilaApp(
                viewModel = viewModel,
                onRequestPermissions = {
                    val missing = requiredNearbyPermissions().filterNot(::isGranted)
                    if (missing.isEmpty()) {
                        viewModel.refreshSystemState(true)
                    } else {
                        permissionLauncher.launch(missing.toTypedArray())
                    }
                },
                onOpenBluetoothSettings = {
                    startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSystemState(hasRequiredNearbyPermissions())
    }

    private fun isGranted(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun hasRequiredNearbyPermissions(): Boolean = requiredNearbyPermissions().all(::isGranted)

    private fun requiredNearbyPermissions(): List<String> = buildList {
        when {
            Build.VERSION.SDK_INT <= 28 -> add(Manifest.permission.ACCESS_COARSE_LOCATION)
            Build.VERSION.SDK_INT in 29..30 -> add(Manifest.permission.ACCESS_FINE_LOCATION)
            Build.VERSION.SDK_INT == 31 -> add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (Build.VERSION.SDK_INT >= 31) {
            add(Manifest.permission.BLUETOOTH_SCAN)
            add(Manifest.permission.BLUETOOTH_ADVERTISE)
            add(Manifest.permission.BLUETOOTH_CONNECT)
        }

        if (Build.VERSION.SDK_INT >= 33) {
            add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }

        if (Build.VERSION.SDK_INT >= 37) {
            add("android.permission.ACCESS_LOCAL_NETWORK")
        }
    }
}
