package org.blueprint.sila.nearby

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.blueprint.sila.data.ChatMessage
import org.blueprint.sila.data.ConnectionRequest
import org.blueprint.sila.data.LocalIdentity
import org.blueprint.sila.data.MessageStore
import org.blueprint.sila.data.Peer
import org.blueprint.sila.data.PeerStatus
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.UUID

/**
 * MVP transport implementation.
 *
 * Nearby Connections is deliberately isolated behind this class so a future
 * NativeBleTransport / WifiDirectTransport can implement the same app-facing behavior.
 */
class NearbyTransport(context: Context) {
    private val appContext = context.applicationContext
    private val client: ConnectionsClient = Nearby.getConnectionsClient(appContext)
    private val identity = LocalIdentity(appContext)
    private val messageStore = MessageStore(appContext)

    private val _state = MutableStateFlow(
        TransportState(
            localName = identity.displayName,
            nodeId = identity.nodeId,
            messages = messageStore.load()
        )
    )
    val state: StateFlow<TransportState> = _state.asStateFlow()

    private val strategy = Strategy.P2P_CLUSTER

    fun startNetwork() {
        if (!_state.value.isAdvertising) startAdvertising()
        if (!_state.value.isDiscovering && _state.value.connectedEndpointId == null) startDiscovery()
    }

    fun stopNetwork() {
        client.stopAdvertising()
        client.stopDiscovery()
        _state.update { it.copy(isAdvertising = false, isDiscovering = false) }
    }

    fun connect(endpointId: String) {
        val peer = _state.value.peers.firstOrNull { it.endpointId == endpointId } ?: return
        updatePeer(endpointId, PeerStatus.CONNECTING)
        client.requestConnection(identity.displayName, endpointId, connectionLifecycleCallback)
            .addOnFailureListener { e ->
                updatePeer(endpointId, PeerStatus.DISCOVERED)
                setError("تعذر طلب الاتصال مع ${peer.name}: ${e.localizedMessage ?: "خطأ غير معروف"}")
            }
    }

    fun acceptPendingConnection() {
        val request = _state.value.pendingConnection ?: return
        client.acceptConnection(request.endpointId, payloadCallback)
            .addOnFailureListener { e -> setError("تعذر قبول الاتصال: ${e.localizedMessage}") }
        _state.update { it.copy(pendingConnection = null) }
    }

    fun rejectPendingConnection() {
        val request = _state.value.pendingConnection ?: return
        client.rejectConnection(request.endpointId)
        _state.update { it.copy(pendingConnection = null) }
    }

    fun sendMessage(text: String) {
        val clean = text.trim()
        val endpointId = _state.value.connectedEndpointId
        if (clean.isEmpty() || endpointId == null) return

        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val json = JSONObject()
            .put("type", "chat")
            .put("id", id)
            .put("senderName", identity.displayName)
            .put("senderNodeId", identity.nodeId)
            .put("text", clean)
            .put("timestamp", now)

        val payload = Payload.fromBytes(json.toString().toByteArray(StandardCharsets.UTF_8))
        client.sendPayload(endpointId, payload)
            .addOnSuccessListener {
                appendMessage(
                    ChatMessage(
                        id = id,
                        senderName = identity.displayName,
                        text = clean,
                        timestamp = now,
                        outgoing = true
                    )
                )
            }
            .addOnFailureListener { e -> setError("فشل إرسال الرسالة: ${e.localizedMessage}") }
    }

    fun clearError() {
        _state.update { it.copy(error = null) }
    }

    fun shutdown() {
        client.stopAllEndpoints()
        stopNetwork()
    }

    private fun startAdvertising() {
        val options = AdvertisingOptions.Builder().setStrategy(strategy).build()
        client.startAdvertising(identity.displayName, SERVICE_ID, connectionLifecycleCallback, options)
            .addOnSuccessListener { _state.update { it.copy(isAdvertising = true, error = null) } }
            .addOnFailureListener { e -> setError("تعذر بدء الإعلان: ${e.localizedMessage}") }
    }

    private fun startDiscovery() {
        val options = DiscoveryOptions.Builder().setStrategy(strategy).build()
        client.startDiscovery(SERVICE_ID, endpointDiscoveryCallback, options)
            .addOnSuccessListener { _state.update { it.copy(isDiscovering = true, error = null) } }
            .addOnFailureListener { e -> setError("تعذر بدء البحث: ${e.localizedMessage}") }
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            _state.update { current ->
                if (current.peers.any { it.endpointId == endpointId }) current
                else current.copy(peers = current.peers + Peer(endpointId, info.endpointName))
            }
        }

        override fun onEndpointLost(endpointId: String) {
            _state.update { current ->
                if (current.connectedEndpointId == endpointId) current
                else current.copy(peers = current.peers.filterNot { it.endpointId == endpointId })
            }
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            _state.update { current ->
                val exists = current.peers.any { it.endpointId == endpointId }
                val peers = if (exists) current.peers else current.peers + Peer(endpointId, info.endpointName)
                current.copy(
                    peers = peers,
                    pendingConnection = ConnectionRequest(
                        endpointId = endpointId,
                        peerName = info.endpointName,
                        authenticationDigits = info.authenticationDigits
                    )
                )
            }
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                updatePeer(endpointId, PeerStatus.CONNECTED)
                _state.update { it.copy(connectedEndpointId = endpointId, error = null) }
                // MVP 1 is intentionally one active peer at a time. Stop radio discovery/advertising
                // after a successful link to reduce battery usage and simplify the test.
                client.stopDiscovery()
                client.stopAdvertising()
                _state.update { it.copy(isDiscovering = false, isAdvertising = false) }
            } else {
                updatePeer(endpointId, PeerStatus.DISCOVERED)
                setError("فشل إتمام الاتصال (الحالة ${result.status.statusCode})")
            }
        }

        override fun onDisconnected(endpointId: String) {
            updatePeer(endpointId, PeerStatus.DISCOVERED)
            _state.update { current ->
                current.copy(
                    connectedEndpointId = if (current.connectedEndpointId == endpointId) null else current.connectedEndpointId
                )
            }
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = payload.asBytes() ?: return
            runCatching {
                val json = JSONObject(String(bytes, StandardCharsets.UTF_8))
                if (json.optString("type") != "chat") return@runCatching
                appendMessage(
                    ChatMessage(
                        id = json.getString("id"),
                        senderName = json.optString("senderName", "جهاز قريب"),
                        text = json.getString("text"),
                        timestamp = json.optLong("timestamp", System.currentTimeMillis()),
                        outgoing = false
                    )
                )
            }.onFailure { setError("وصلت بيانات غير صالحة من الجهاز القريب") }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) = Unit
    }

    private fun updatePeer(endpointId: String, status: PeerStatus) {
        _state.update { current ->
            current.copy(peers = current.peers.map { if (it.endpointId == endpointId) it.copy(status = status) else it })
        }
    }

    private fun appendMessage(message: ChatMessage) {
        _state.update { current ->
            if (current.messages.any { it.id == message.id }) current
            else {
                val updated = (current.messages + message).takeLast(200)
                messageStore.save(updated)
                current.copy(messages = updated)
            }
        }
    }

    private fun setError(message: String) {
        _state.update { it.copy(error = message) }
    }

    companion object {
        private const val SERVICE_ID = "org.blueprint.sila"
    }
}

data class TransportState(
    val localName: String,
    val nodeId: String,
    val isAdvertising: Boolean = false,
    val isDiscovering: Boolean = false,
    val peers: List<Peer> = emptyList(),
    val connectedEndpointId: String? = null,
    val pendingConnection: ConnectionRequest? = null,
    val messages: List<ChatMessage> = emptyList(),
    val error: String? = null
)
