package org.blueprint.sila.nearby

import android.bluetooth.BluetoothManager
import android.content.Context
import android.provider.Settings
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.blueprint.sila.data.ChatMessage
import org.blueprint.sila.data.ConnectionRequest
import org.blueprint.sila.data.LocalIdentity
import org.blueprint.sila.data.MessageStore
import org.blueprint.sila.data.Peer
import org.blueprint.sila.data.PeerStatus
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.UUID

class NearbyTransport(context: Context) {
    private val appContext = context.applicationContext
    private val client: ConnectionsClient = Nearby.getConnectionsClient(appContext)
    private val identity = LocalIdentity(appContext)
    private val messageStore = MessageStore(appContext)
    private val strategy = Strategy.P2P_CLUSTER

    private val _state = MutableStateFlow(
        TransportState(
            localName = identity.displayName,
            nodeId = identity.nodeId,
            messages = messageStore.load()
        )
    )
    val state: StateFlow<TransportState> = _state.asStateFlow()

    fun refreshSystemState(permissionsGranted: Boolean) {
        val playServicesAvailable = GoogleApiAvailability.getInstance()
            .isGooglePlayServicesAvailable(appContext) == ConnectionResult.SUCCESS

        val bluetoothManager = appContext.getSystemService(BluetoothManager::class.java)
        val adapter = bluetoothManager?.adapter
        val bluetoothEnabled = runCatching { adapter?.isEnabled == true }.getOrDefault(false)
        val airplaneMode = runCatching {
            Settings.Global.getInt(appContext.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        }.getOrDefault(false)

        _state.update {
            it.copy(
                permissionsGranted = permissionsGranted,
                playServicesAvailable = playServicesAvailable,
                bluetoothAvailable = adapter != null,
                bluetoothEnabled = bluetoothEnabled,
                airplaneMode = airplaneMode
            )
        }
    }

    fun startNetwork() {
        val current = _state.value
        when {
            !current.permissionsGranted -> {
                setError("يلزم منح أذونات الأجهزة القريبة قبل تشغيل الشبكة.")
                return
            }
            !current.playServicesAvailable -> {
                setError("خدمات Google Play غير متاحة على هذا الهاتف. هذه النسخة تحتاجها للاتصال المحلي؛ سنضيف النقل الأصلي BLE/Wi‑Fi Direct كبديل في الإصدار التالي.")
                return
            }
            !current.bluetoothAvailable -> {
                setError("الهاتف لا يوفّر Bluetooth، ولا يمكن بدء الاكتشاف بهذه النسخة.")
                return
            }
            !current.bluetoothEnabled -> {
                setError("Bluetooth متوقف. فعّله على الهاتفين ثم أعد تشغيل الشبكة. يمكن إبقاء وضع الطيران مفعّلًا.")
                return
            }
        }

        _state.update {
            it.copy(
                networkRequested = true,
                isStarting = true,
                error = null,
                lastEvent = "جارٍ تهيئة الاتصال المحلي…"
            )
        }
        if (!_state.value.isAdvertising) startAdvertising()
        if (!_state.value.isDiscovering && _state.value.connectedEndpointId == null) startDiscovery()
    }

    fun stopNetwork() {
        client.stopAdvertising()
        client.stopDiscovery()
        _state.update {
            it.copy(
                networkRequested = false,
                isStarting = false,
                isAdvertising = false,
                isDiscovering = false,
                lastEvent = "الشبكة المحلية متوقفة"
            )
        }
    }

    fun connect(endpointId: String) {
        val peer = _state.value.peers.firstOrNull { it.endpointId == endpointId } ?: return
        updatePeer(endpointId, PeerStatus.CONNECTING)
        _state.update { it.copy(lastEvent = "جارٍ طلب الاتصال بـ ${peer.name}…") }
        client.requestConnection(identity.displayName, endpointId, connectionLifecycleCallback)
            .addOnFailureListener { e ->
                updatePeer(endpointId, PeerStatus.DISCOVERED)
                setApiError("تعذر طلب الاتصال مع ${peer.name}", e)
            }
    }

    fun acceptPendingConnection() {
        val request = _state.value.pendingConnection ?: return
        client.acceptConnection(request.endpointId, payloadCallback)
            .addOnFailureListener { e -> setApiError("تعذر قبول الاتصال", e) }
        _state.update { it.copy(pendingConnection = null, lastEvent = "تمت الموافقة؛ بانتظار إتمام الاتصال…") }
    }

    fun rejectPendingConnection() {
        val request = _state.value.pendingConnection ?: return
        client.rejectConnection(request.endpointId)
        _state.update { it.copy(pendingConnection = null, lastEvent = "تم رفض طلب الاتصال") }
    }

    fun sendMessage(text: String) {
        val clean = text.trim()
        val endpointId = _state.value.connectedEndpointId
        if (clean.isEmpty() || endpointId == null) return

        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val json = JSONObject()
            .put("type", "chat")
            .put("id", id)
            .put("senderName", identity.displayName)
            .put("senderNodeId", identity.nodeId)
            .put("text", clean)
            .put("timestamp", now)

        client.sendPayload(endpointId, Payload.fromBytes(json.toString().toByteArray(StandardCharsets.UTF_8)))
            .addOnSuccessListener {
                appendMessage(ChatMessage(id, identity.displayName, clean, now, true))
                _state.update { it.copy(lastEvent = "تم إرسال الرسالة محليًا") }
            }
            .addOnFailureListener { e -> setApiError("فشل إرسال الرسالة", e) }
    }

    fun clearError() {
        _state.update { it.copy(error = null) }
    }

    fun shutdown() {
        client.stopAllEndpoints()
        stopNetwork()
    }

    private fun startAdvertising() {
        val options = AdvertisingOptions.Builder().setStrategy(strategy).build()
        client.startAdvertising(identity.displayName, SERVICE_ID, connectionLifecycleCallback, options)
            .addOnSuccessListener {
                _state.update {
                    it.copy(
                        isAdvertising = true,
                        isStarting = !(it.isDiscovering || it.connectedEndpointId != null),
                        error = null,
                        lastEvent = "الجهاز مرئي للأجهزة القريبة"
                    )
                }
            }
            .addOnFailureListener { e ->
                _state.update { it.copy(isStarting = false, isAdvertising = false) }
                setApiError("تعذر جعل الجهاز مرئيًا", e)
            }
    }

    private fun startDiscovery() {
        val options = DiscoveryOptions.Builder().setStrategy(strategy).build()
        client.startDiscovery(SERVICE_ID, endpointDiscoveryCallback, options)
            .addOnSuccessListener {
                _state.update {
                    it.copy(
                        isDiscovering = true,
                        isStarting = false,
                        error = null,
                        lastEvent = "جارٍ البحث عن أجهزة صلة القريبة…"
                    )
                }
            }
            .addOnFailureListener { e ->
                _state.update { it.copy(isStarting = false, isDiscovering = false) }
                setApiError("تعذر بدء البحث عن الأجهزة", e)
            }
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            _state.update { current ->
                val peers = if (current.peers.any { it.endpointId == endpointId }) current.peers
                else current.peers + Peer(endpointId, info.endpointName)
                current.copy(peers = peers, lastEvent = "تم العثور على ${info.endpointName}")
            }
        }

        override fun onEndpointLost(endpointId: String) {
            _state.update { current ->
                if (current.connectedEndpointId == endpointId) current
                else current.copy(peers = current.peers.filterNot { it.endpointId == endpointId })
            }
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            _state.update { current ->
                val peers = if (current.peers.any { it.endpointId == endpointId }) current.peers
                else current.peers + Peer(endpointId, info.endpointName)
                current.copy(
                    peers = peers,
                    pendingConnection = ConnectionRequest(endpointId, info.endpointName, info.authenticationDigits),
                    lastEvent = "طلب اتصال من ${info.endpointName}"
                )
            }
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                updatePeer(endpointId, PeerStatus.CONNECTED)
                val peerName = _state.value.peers.firstOrNull { it.endpointId == endpointId }?.name ?: "جهاز قريب"
                _state.update {
                    it.copy(
                        connectedEndpointId = endpointId,
                        error = null,
                        isStarting = false,
                        lastEvent = "متصل الآن بـ $peerName"
                    )
                }
                client.stopDiscovery()
                client.stopAdvertising()
                _state.update { it.copy(isDiscovering = false, isAdvertising = false) }
            } else {
                updatePeer(endpointId, PeerStatus.DISCOVERED)
                setError("فشل إتمام الاتصال — رمز الحالة ${result.status.statusCode}")
            }
        }

        override fun onDisconnected(endpointId: String) {
            updatePeer(endpointId, PeerStatus.DISCOVERED)
            val shouldRestart = _state.value.networkRequested
            _state.update { current ->
                current.copy(
                    connectedEndpointId = if (current.connectedEndpointId == endpointId) null else current.connectedEndpointId,
                    lastEvent = "انقطع الاتصال بالجهاز القريب"
                )
            }
            if (shouldRestart) {
                if (!_state.value.isAdvertising) startAdvertising()
                if (!_state.value.isDiscovering) startDiscovery()
            }
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = payload.asBytes() ?: return
            runCatching {
                val json = JSONObject(String(bytes, StandardCharsets.UTF_8))
                if (json.optString("type") != "chat") return@runCatching
                appendMessage(
                    ChatMessage(
                        id = json.getString("id"),
                        senderName = json.optString("senderName", "جهاز قريب"),
                        text = json.getString("text"),
                        timestamp = json.optLong("timestamp", System.currentTimeMillis()),
                        outgoing = false
                    )
                )
                _state.update { it.copy(lastEvent = "وصلت رسالة جديدة") }
            }.onFailure { setError("وصلت بيانات غير صالحة من الجهاز القريب") }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) = Unit
    }

    private fun updatePeer(endpointId: String, status: PeerStatus) {
        _state.update { current ->
            current.copy(peers = current.peers.map { if (it.endpointId == endpointId) it.copy(status = status) else it })
        }
    }

    private fun appendMessage(message: ChatMessage) {
        _state.update { current ->
            if (current.messages.any { it.id == message.id }) current
            else {
                val updated = (current.messages + message).takeLast(200)
                messageStore.save(updated)
                current.copy(messages = updated)
            }
        }
    }

    private fun setApiError(prefix: String, error: Exception) {
        val status = (error as? ApiException)?.statusCode
        val suffix = when (status) {
            8007 -> "مشكلة في Bluetooth/Wi‑Fi. تأكد من تشغيلهما على الهاتفين."
            8034 -> "يوجد إذن مطلوب غير ممنوح."
            else -> error.localizedMessage ?: "خطأ غير معروف"
        }
        setError("$prefix: $suffix")
    }

    private fun setError(message: String) {
        _state.update { it.copy(error = message, lastEvent = message, isStarting = false) }
    }

    companion object {
        private const val SERVICE_ID = "org.blueprint.sila"
    }
}

data class TransportState(
    val localName: String,
    val nodeId: String,
    val permissionsGranted: Boolean = false,
    val playServicesAvailable: Boolean = false,
    val bluetoothAvailable: Boolean = true,
    val bluetoothEnabled: Boolean = false,
    val airplaneMode: Boolean = false,
    val networkRequested: Boolean = false,
    val isStarting: Boolean = false,
    val isAdvertising: Boolean = false,
    val isDiscovering: Boolean = false,
    val peers: List<Peer> = emptyList(),
    val connectedEndpointId: String? = null,
    val pendingConnection: ConnectionRequest? = null,
    val messages: List<ChatMessage> = emptyList(),
    val lastEvent: String = "جاهز للتهيئة",
    val error: String? = null
) {
    val readyForNetwork: Boolean
        get() = permissionsGranted && playServicesAvailable && bluetoothAvailable && bluetoothEnabled
}
