package org.blueprint.sila.data

enum class PeerStatus {
    DISCOVERED,
    CONNECTING,
    CONNECTED
}

data class Peer(
    val endpointId: String,
    val name: String,
    val status: PeerStatus = PeerStatus.DISCOVERED
)

data class ConnectionRequest(
    val endpointId: String,
    val peerName: String,
    val authenticationDigits: String
)

data class ChatMessage(
    val id: String,
    val senderName: String,
    val text: String,
    val timestamp: Long,
    val outgoing: Boolean
)
